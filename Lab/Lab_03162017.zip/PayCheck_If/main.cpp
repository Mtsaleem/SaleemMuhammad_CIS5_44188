/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 16, 2017, 12:24 PM
 * Purpose:  Calculate Pay
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int payChck,
        hrsWrkd,
        //defPay ,
        payRate;
    
    //Input or initialize values Here
    payRate =  10 ;
    //defPay  = 400 ;
    
    //Process/Calculations Here
    cout<<"This program is to calculate your pay check"<<endl;
    cout<<"Please input the amount of hours you worked"<<endl;
    cin >>hrsWrkd;
    payChck = (payRate * hrsWrkd) + payRate(hrsWrkd - 40);
    if (hrsWrkd<=40)payChck;
    //payChck = payRate * hrsWrkd;
    else payChck;
    
    //Output Located Here
    cout<<"For "<<hrsWrkd<<" hours worked you will get "<<payChck<<endl;

    //Exit
    return 0;
}

