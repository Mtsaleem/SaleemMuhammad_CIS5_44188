/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Calculate Gross Pay
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float payChk, //Paycheck in $'s
          hrsWrkd,//Hours worked in hours
          payRate;//Pay rate in $'s/hour
    
    //Input or initialize values Here
    hrsWrkd=40;
    payRate=10;
    
    //Map inputs to outputs or process the data
    payChk=hrsWrkd*payRate;
       
    //Output Located Here
    cout<<"Hours worked = "<<hrsWrkd<<" (hrs)"<<endl;
    cout<<"Pay rate = $"<<payRate<<"/hr"<<endl;
    cout<<"Gross Pay = $"<<payChk<<endl;

    //Exit
    return 0;
}

