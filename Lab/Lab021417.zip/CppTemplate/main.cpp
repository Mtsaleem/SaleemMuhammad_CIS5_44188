
/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on February 14, 2017, 11:29 AM
 * Purpose: Template to be utilized in creating
 *          solutions to problems in our CSC/CIS 5
 *          class.
 */
//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//GLobal Constants

//Function Prototypes

//Execution Begins here
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables 
    
    //Input Data
    
    //Map inputs to outputs to process the data
    
    //Output the transformed data
    
    //Exit Stage right!
    return 0;
}

