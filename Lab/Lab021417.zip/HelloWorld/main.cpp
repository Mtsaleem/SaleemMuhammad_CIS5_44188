/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on February 14, 2017, 11:29 AM
 * Purpose: Our first program
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//GLobal Constants

//Function Prototypes

//Execution Begins here
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables 
    
    //Input Data
    
    //Map inputs to outputs to process the data
    
    //Output the transformed data
    cout<<"Hello World"<<endl;
    
    //Exit Stage right!
    return 0;
}

