/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on February 25, 2017, 11:34 AM
 * Purpose:  To output CS in-between two lines
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"*************************************************************"<<endl;
    cout<<"                 ccc     "<<"    ssss     "<<"!!"             <<endl;
    cout<<"                c   c    "<<"  s     s    "<<"!!"             <<endl;
    cout<<"               c         "<<" s           "<<"!!"             <<endl;
    cout<<"              c          "<<"  s          "<<"!!"             <<endl;
    cout<<"              c          "<<"   ssss      "<<"!!"             <<endl;
    cout<<"              c          "<<"        s    "<<"!!"             <<endl;
    cout<<"               c         "<<"         s   "<<"!!"             <<endl;
    cout<<"                c   c    "<<"  s     s    "                   <<endl;
    cout<<"                 ccc     "<<"    ssss     "<<"00"             <<endl;
    cout<<"*************************************************************"<<endl;
    
    //Exit stage right!
    return 0;
}

