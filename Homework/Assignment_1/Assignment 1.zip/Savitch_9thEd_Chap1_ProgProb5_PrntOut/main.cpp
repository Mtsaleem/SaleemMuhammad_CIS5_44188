/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on February 27, 2017, 10:27 AM
 * Purpose:  To have an output of letter C
 *            made out of an input letter
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare Variables
    char C;
    
    //Initialize variables
   
    //Input data
   
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"Enter a letter on the keyboard ";
    cin>>C;
    
    cout<<"  "<<C<<" "<<C<<" "<<C<<endl;
    cout<<" "<<C<<"    "<<C<<endl;
    cout<<C<<endl;
    cout<<C<<endl;
    cout<<C<<endl;
    cout<<C<<endl;
    cout<<C<<endl;
    cout<<" "<<C<<"    "<<C<<endl;
    cout<<"  "<<C<<" "<<C<<" "<<C<<endl;
    return 0;
}

