/* 
 * File:   main.cpp
 * Author: Muhammad Saleem 
 * Created on March 20, 2017, 11:03 PM
 * Purpose:  This program is to convert seconds into minutes, hours, or days
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const int  MINUTE=60;     //How many seconds in a minute
const int  HOUR=60*MINUTE;//How many seconds in a hour
const int  DAY=24*HOUR;   //How many seconds in a day
const int  WEEK=7*DAY;    //How many seconds in a week
const int  YEAR=52*WEEK;  //How many seconds in a year

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare Variables
    int nSecs  ;//Number of seconds to convert
    int nYrs   ,
        nMnths ,
        nWks   ,
        nDys   ,
        nHrs   ,
        nMin   ;
    
    //Initialize variables
   
    cout<<"This program converts seconds to Years/Months/Weeks/Days/Hours"<<endl;
    cout<<"Input the number of seconds for the conversion/equivalence"<<endl;
    cin>>nSecs;
    
    //Map inputs to outputs or process the data
    nYrs=nSecs/YEAR;          
    cout<<nYrs<<" Years (";
    nSecs-=nYrs*YEAR;         
    
    nWks=nSecs/WEEK;          
    cout<<nWks<<" Weeks or ";
    nMnths=nWks*3/13;         
    cout<<nMnths<<" Months ) ";
    nSecs-=nWks*WEEK;         
    
    nDys=nSecs/DAY;           
    cout<<nDys<<" Days ";
    nSecs-=nDys*DAY;          
    
    nHrs=nSecs/HOUR;          
    cout<<nHrs<<" Hours ";
    nSecs-=nHrs*HOUR;         
    
    nMin=nSecs/MINUTE;        
    cout<<nMin<<" Minutes ";
    
    nSecs-=nMin*MINUTE;       
    cout<<nSecs<<" Seconds";
    
    //Output the transformed data
    
    return 0;
}

