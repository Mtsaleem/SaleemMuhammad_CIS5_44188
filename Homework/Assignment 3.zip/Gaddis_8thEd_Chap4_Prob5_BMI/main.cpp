/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 20, 2017, 09:50 PM
 * Purpose:  To calculate the BMI of a person 
 *           and to tell if the person is of optimal weight
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float weight  ,  //Given weight in pounds
          height  ,  //Given height in inches
          BMI     ;  //Body Mass Index
    
    //Initialize variables
   
    //Input data
    cout<<"This program is to find out your Body Mass Index"<<endl;
    cout<<"Enter your weight in pounds"<<endl;
    cin >>weight;
    cout<<"Enter your height in inches"<<endl;
    cin >>height;
    
    //Map inputs to outputs or process the data
    BMI = (weight * 703) / (height * height);
    
    //Output the transformed data
    if(BMI < 18.5)
    cout<<"You are under the recommended weight"<<endl;
    if(BMI >= 18.5 && BMI <= 25)
    cout<<"You are at the recommended weight"<<endl;
    if(BMI > 25)
    cout<<"You are over the recommended weight"<<endl;
    
    return 0;
}

