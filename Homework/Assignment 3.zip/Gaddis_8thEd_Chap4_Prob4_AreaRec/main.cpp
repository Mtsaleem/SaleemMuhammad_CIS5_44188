/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 20, 2017, 09:23 PM
 * Purpose:  To calculate the areas of two 
 *           rectangles and find out which one is larger
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float len1  ,  //Length of first rectangle
          len2  ,  //Length of second rectangle
          wid1  ,  //Width of first rectangle
          wid2  ,  //Width of second rectangle
          area1 ,  //Area of first rectangle
          area2 ;  //Area of second rectangle
    
    //Initialize variables
   
    //Input data
    cout<<"This program is to find out which of the areas of the two "<<endl;
    cout<<"rectangles are larger"<<endl;
    cout<<"Enter the length of the first rectangle"<<endl;
    cin >>len1;
    cout<<"Enter the width of the first rectangle"<<endl;
    cin >>wid1;
    cout<<"Enter the length of the second rectangle"<<endl;
    cin >>len2;
    cout<<"Enter the width of the second rectangle"<<endl;
    cin >>wid2;
    
    //Map inputs to outputs or process the data
    area1 = len1 * wid1;
    area2 = len2 * wid2;
    
    //Output the transformed data
    if(area1 > area2)
    cout<<"The area of the first rectangle is greater then the area of the "
            "second one"<<endl;
    else if(area2 > area1)
    cout<<"The area of the second rectangle is greater then the first one"<<endl;
    else if(area1 == area2)
    cout<<"The area of both the rectangles is the same"<<endl;
    
    return 0;
}

