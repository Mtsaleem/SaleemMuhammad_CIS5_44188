/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 20, 2017, 08:33 PM
 * Purpose:  To find out if a date given is a magic date
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare Variables
    float mont  ,  //Given Month
          day   ,  //Given Day
          year  ;  //Given Year
    
    //Initialize variables
   
    //Input data
    cout<<"This program is to find out if your date is a magic date"<<endl;
    cout<<"Please enter a month in numerical form"<<endl;
    cin >>mont;
    cout<<"Enter a day of the month"<<endl;
    cin >>day;
    cout<<"Enter the last two digits of the year"<<endl;
    cin >>year;
    
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    if(mont * day == year)
    cout<<"This date is a MAGIC DATE!"<<endl;
    else
    cout<<"The date Is NOT a MAGIC DATE"<<endl;
    
    return 0;
}

