/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 17, 2017, 08:00 PM
 * Purpose:  To determine which number 
 *           is bigger and which is smaller from an entered set
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float num1,
          num2;
    
    //Input data
    cout<<"This program is to tell you which of two given integers is "<<endl;
    cout<<"larger and which is smaller."<<endl;
    cout<<"Please enter an integer"<<endl;
    cin >>num1;
    cout<<"Please enter another integer"<<endl;
    cin >>num2;
       
    //Map inputs to outputs or process the data
    num1>num2 ? cout<<num1<<" Is larger and "<<num2<<" is smaller" 
    :cout<<num2<<" Is larger and "<<num1<<" is smaller"<<endl;
    
    //Output the transformed data
    
    return 0;
}

