/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 20, 2017, 10:46 PM
 * Purpose:  To calculate the given weight from mass
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float mass    ,
          weight  ;  //Weight in kilograms
    
    //Initialize variables
   
    //Input data
    cout<<"This program is to calculate the weight of a given mass"<<endl;
    cout<<"Please enter mass of the object in kilograms"<<endl;
    cin >>mass;
    
    //Map inputs to outputs or process the data
    weight = mass * 9.8;
    
    //Output the transformed data
    if(weight > 1000)
        cout<<"The mass is "<<weight<<" newtons"<<endl;
        cout<<"The mass of the object is too heavy"<<endl;
    if(weight < 10)
        cout<<"The mass is "<<weight<<" newtons"<<endl;
        cout<<"The mass of the object is too low"<<endl;
    if(weight>=10&&weight<=1000)
        cout<<"The mass is "<<weight<<" newtons"<<endl;
            
    
    
    return 0;
}

