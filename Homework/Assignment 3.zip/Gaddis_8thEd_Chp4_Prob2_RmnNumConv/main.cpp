/* 
 * File:   main.cpp
 * Author: Muhammad Saleem
 * Created on March 17, 2017, 09:20 PM
 * Purpose:  This program is to convert 
 *            a given number between 0 and 10 into Roman numerals
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short   num    ;  //Regular number
    char romNum ;  //Roman number
    
    //Input data
    cout<<"This program converts a given number into Roman Numeral"<<endl;
    cout<<"The data types is an integer between [1-10]"<<endl;
    cout<<"Enter in a integer"<<endl;
    cin >>num;
    if (!(num>=1&&num<=10)){
        cout<<"You have failed to type in an integer between 1 and 10"<<endl;
        return 1;
    }
    
    //Map inputs to outputs or process the data
    switch(num){
        case 1:cout<<"I"<<endl;break;
        case 2:cout<<"II"<<endl;break;
        case 3:cout<<"III"<<endl;break;
        case 4:cout<<"IV"<<endl;break;
        case 5:cout<<"V"<<endl;break;
        case 6:cout<<"VI"<<endl;break;
        case 7:cout<<"VII"<<endl;break;
        case 8:cout<<"VIII"<<endl;break;
        case 9:cout<<"IX"<<endl;break;
        case 10:cout<<"X"<<endl;break;
    }
   
    //Output the transformed data
    cout<<"For the number "<<num<<" the Roman Numeral would be "<<romNum<<endl;
    
    return 0;
}

